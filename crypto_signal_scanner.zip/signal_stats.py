import pandas as pd

def calculate_signal_stats(df):
    results = df[df['Signal'].notnull()].copy()
    results['Return'] = df['Close'].pct_change().shift(-1)
    results['Profit'] = results.apply(
        lambda x: x['Return'] if x['Signal'] == 'BUY' else -x['Return'], axis=1
    )

    winrate = (results['Profit'] > 0).mean()
    avg_profit = results['Profit'].mean()
    total_signals = len(results)

    print(f"📈 Tổng tín hiệu: {total_signals}")
    print(f"✅ Winrate: {winrate * 100:.2f}%")
    print(f"💰 Lợi nhuận trung bình: {avg_profit * 100:.2f}%")

    return {
        'total_signals': total_signals,
        'winrate': winrate,
        'avg_profit': avg_profit
    }
