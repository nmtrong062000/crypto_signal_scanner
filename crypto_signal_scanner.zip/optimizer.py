import json
import itertools
from data_fetcher import get_historical_data
from strategy import generate_signals
from signal_stats import calculate_signal_stats

def run_backtest(config):
    df = get_historical_data('BTCUSDT', '1h', days=365)
    df = generate_signals(df, config)
    stats = calculate_signal_stats(df)
    return stats['winrate'], stats['avg_profit']

def optimize():
    best_config = None
    best_score = -999

    EMA_fast_list = [10, 15, 20]
    EMA_slow_list = [25, 30, 40]
    BB_period_list = [20, 25]
    RSI_period_list = [14, 20]

    for ema_fast, ema_slow, bb, rsi in itertools.product(EMA_fast_list, EMA_slow_list, BB_period_list, RSI_period_list):
        config = {
            'EMA_fast': ema_fast,
            'EMA_slow': ema_slow,
            'BB_period': bb,
            'RSI_period': rsi
        }

        winrate, avg_profit = run_backtest(config)
        score = winrate * 0.8 + avg_profit * 0.2

        print(f"⚙️ Testing {config} → Winrate: {winrate:.2f}, Avg: {avg_profit:.4f}")

        if score > best_score:
            best_score = score
            best_config = config

    print("\n🏆 Cấu hình tốt nhất:")
    print(best_config)

    with open('best_config.json', 'w') as f:
        json.dump(best_config, f, indent=4)

    # Cập nhật config.py tự động
    with open('config.py', 'w') as f:
        f.write(f"CONFIG = {json.dumps(best_config, indent=4)}")

if __name__ == '__main__':
    optimize()
