import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone
from binance.client import Client
from strategy import generate_signals
from config import COIN_LIST, EMA_SHORT, EMA_MID, EMA_LONG, BB_STD, VOL_MULT

client = Client()

# Giới hạn khung thời gian
TIMEFRAME = "1h"
VIETNAM_TZ = timezone(timedelta(hours=7))
BACKTEST_MONTHS = 12
RESULT_FILE = "backtest_trades.csv"

def get_historical_data(symbol, interval="1h", months=12):
    """Lấy dữ liệu 1 năm gần nhất từ Binance Futures"""
    end_time = datetime.now(timezone.utc)
    start_time = end_time - timedelta(days=30 * months)

    klines = client.futures_historical_klines(
        symbol=symbol,
        interval=interval,
        start_str=start_time.strftime("%Y-%m-%d %H:%M:%S"),
        end_str=end_time.strftime("%Y-%m-%d %H:%M:%S")
    )

    df = pd.DataFrame(klines, columns=[
        'time','open','high','low','close','volume','close_time',
        'quote_asset_vol','num_trades','taker_base_vol','taker_quote_vol','ignore'
    ])
    df['time'] = pd.to_datetime(df['time'], unit='ms')
    df[['open','high','low','close','volume']] = df[['open','high','low','close','volume']].astype(float)
    return df[['time','open','high','low','close','volume']]


def run_backtest(ema_short=EMA_SHORT, ema_mid=EMA_MID, ema_long=EMA_LONG, bb_std=BB_STD, vol_mult=VOL_MULT):
    trades = []
    for symbol in COIN_LIST[:20]:  # Giới hạn để tránh API quá tải
        try:
            df = get_historical_data(symbol, TIMEFRAME, BACKTEST_MONTHS)
            if len(df) < 200:
                continue

            df_signals = generate_signals(df, ema_short, ema_mid, ema_long, bb_std, vol_mult)
            if df_signals.empty:
                continue

            for _, row in df_signals.iterrows():
                entry_price = row["Entry"]
                tp = row["TP"]
                sl = row["SL"]
                signal = row["Signal"]

                next_candles = df[df["time"] > row["time"]].head(20)
                if next_candles.empty:
                    continue

                if signal == "BUY":
                    hit_tp = (next_candles["high"] >= tp).any()
                    hit_sl = (next_candles["low"] <= sl).any()
                    profit_pct = 2 if hit_tp else (-1 if hit_sl else 0)
                    is_win = profit_pct > 0

                else:  # SELL
                    hit_tp = (next_candles["low"] <= tp).any()
                    hit_sl = (next_candles["high"] >= sl).any()
                    profit_pct = 2 if hit_tp else (-1 if hit_sl else 0)
                    is_win = profit_pct > 0

                trades.append({
                    "symbol": symbol,
                    "interval": TIMEFRAME,
                    "signal": signal,
                    "entry": entry_price,
                    "tp": tp,
                    "sl": sl,
                    "profit_pct": profit_pct,
                    "is_win": is_win,
                    "time": row["time"],
                })
        except Exception as e:
            print(f"❌ Lỗi {symbol}: {e}")

    df_trades = pd.DataFrame(trades)
    if not df_trades.empty:
        win_rate = df_trades["is_win"].mean() * 100
        total_profit = df_trades["profit_pct"].sum()
        df_trades.to_csv(RESULT_FILE, index=False)
        print(f"✅ Backtest hoàn tất | Win Rate = {win_rate:.2f}% | Lợi nhuận: {total_profit:.2f}%")
        return {"win_rate": win_rate, "total_profit": total_profit}
    else:
        print("❌ Không có tín hiệu nào được tạo.")
        return None


if __name__ == "__main__":
    run_backtest()
