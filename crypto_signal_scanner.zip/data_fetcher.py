# file: data_fetcher.py

import pandas as pd
import requests

BASE_URL = "https://fapi.binance.com"  # Binance Futures API

def get_binance_data(symbol="BTCUSDT", interval="1h", limit=500):
    """
    Lấy dữ liệu nến từ Binance Futures.
    Trả về DataFrame với cột: time, open, high, low, close, volume
    """
    endpoint = f"/fapi/v1/klines"
    url = f"{BASE_URL}{endpoint}?symbol={symbol.upper()}&interval={interval}&limit={limit}"

    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()

        if not data or isinstance(data, dict) and "code" in data:
            raise ValueError(data.get("msg", "Không có dữ liệu từ Binance."))

        df = pd.DataFrame(data, columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_asset_vol", "num_trades",
            "taker_base_vol", "taker_quote_vol", "ignore"
        ])

        df["time"] = pd.to_datetime(df["open_time"], unit="ms")
        df[["open", "high", "low", "close", "volume"]] = df[["open", "high", "low", "close", "volume"]].astype(float)

        return df[["time", "open", "high", "low", "close", "volume"]]

    except Exception as e:
        raise Exception(f"Lỗi khi lấy dữ liệu {symbol} ({interval}): {e}")
