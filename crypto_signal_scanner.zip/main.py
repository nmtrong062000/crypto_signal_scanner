import pandas as pd
from datetime import datetime, timedelta, timezone
import time
import os
import json

from config import COIN_LIST, TIMEFRAMES, EMA_SHORT, EMA_MID, EMA_LONG, BB_STD, VOL_MULT
from data_fetcher import get_binance_data
from strategy import generate_signals
from alert import send_discord_alert

# Ưu tiên khung thời gian (1h > 30m > 15m)
TIMEFRAME_PRIORITY = {"15m": 1, "30m": 2, "1h": 3}

# Giới hạn tín hiệu mới (≤ 3 nến gần nhất)
FRESH_SIGNAL_LIMIT = {
    "15m": 15 * 60 * 3,
    "30m": 30 * 60 * 3,
    "1h": 60 * 60 * 3
}

# File lưu tín hiệu đã gửi để chống spam
SENT_FILE = "sent_signals.json"

# Giờ Việt Nam (UTC+7)
VIETNAM_TZ = timezone(timedelta(hours=7))

def load_sent_signals():
    """Đọc danh sách tín hiệu đã gửi (nếu có)"""
    if os.path.exists(SENT_FILE):
        with open(SENT_FILE, "r") as f:
            return set(json.load(f))
    return set()

def save_sent_signals(sent_signals):
    """Lưu danh sách tín hiệu đã gửi"""
    with open(SENT_FILE, "w") as f:
        json.dump(list(sent_signals), f)

def scan_all():
    all_signals = []
    coin_signals = {}
    sent_signals = load_sent_signals()

    now_vn = datetime.now(VIETNAM_TZ)
    print(f"\n⏳ Bắt đầu quét lúc: {now_vn.strftime('%Y-%m-%d %H:%M:%S')} (Giờ Việt Nam)")

    for symbol in COIN_LIST:
        for interval in TIMEFRAMES:
            try:
                df = get_binance_data(symbol, interval, limit=500)
                if len(df) < 100:
                    print(f"⚠️  {symbol} ({interval}) - Không đủ dữ liệu nến, bỏ qua...")
                    continue

                signals = generate_signals(df, EMA_SHORT, EMA_MID, EMA_LONG, BB_STD, VOL_MULT)
                if signals.empty:
                    continue

                latest = signals.iloc[-1]
                signal_time_utc = pd.to_datetime(latest["time"], utc=True)
                signal_time_vn = signal_time_utc.astimezone(VIETNAM_TZ)
                now = datetime.now(timezone.utc)
                time_diff = (now - signal_time_utc).total_seconds()

                # Chỉ lấy tín hiệu mới
                if time_diff > FRESH_SIGNAL_LIMIT[interval]:
                    continue

                # Ưu tiên khung lớn hơn
                if (
                    symbol not in coin_signals
                    or TIMEFRAME_PRIORITY[interval] > TIMEFRAME_PRIORITY[coin_signals[symbol]["interval"]]
                ):
                    coin_signals[symbol] = {
                        "interval": interval,
                        "signal": latest["Signal"],
                        "entry": latest["Entry"],
                        "tp": latest["TP"],
                        "sl": latest["SL"],
                        "time": signal_time_vn.strftime('%Y-%m-%d %H:%M:%S'),
                    }

            except Exception as e:
                print(f"❌ Lỗi khi quét {symbol} {interval}: {e}")

    # Gửi tín hiệu mới và lưu log
    if coin_signals:
        for symbol, data in coin_signals.items():
            signal_id = f"{symbol}_{data['interval']}_{data['time']}"
            if signal_id not in sent_signals:
                print(f"🔔 {symbol} ({data['interval']}) -> {data['signal']} @ {data['entry']} [{data['time']}]")
                send_discord_alert(
                    symbol,
                    data["interval"],
                    data["signal"],
                    data["entry"],
                    data["tp"],
                    data["sl"],
                    data["time"],
                )
                sent_signals.add(signal_id)
                all_signals.append(
                    [symbol, data["interval"], data["time"], data["signal"], data["entry"], data["tp"], data["sl"]]
                )
            else:
                print(f"⏩ {symbol} ({data['interval']}) - Đã gửi Discord trước đó, bỏ qua.")

        # Lưu log tín hiệu mới và danh sách đã gửi
        if all_signals:
            pd.DataFrame(
                all_signals, columns=["Symbol", "Interval", "Time (VN)", "Signal", "Entry", "TP", "SL"]
            ).to_csv("signals.csv", index=False)
            save_sent_signals(sent_signals)
            print("✅ Đã lưu signals.csv (Giờ Việt Nam)")
        else:
            print("ℹ️  Không có tín hiệu mới nào chưa gửi Discord.")
    else:
        print("❌ Không có tín hiệu mới.")

    print(f"✅ Quét hoàn tất lúc: {datetime.now(VIETNAM_TZ).strftime('%Y-%m-%d %H:%M:%S')} (Giờ Việt Nam)")

# --- LOOP CHÍNH ---
if __name__ == "__main__":
    while True:
        scan_all()
        print("🕔 Bắt đầu vòng lặp tiếp theo...\n")
        # print("🕔 Đang chờ 5 phút trước lần quét tiếp theo...\n")
        # time.sleep(5 * 60)
